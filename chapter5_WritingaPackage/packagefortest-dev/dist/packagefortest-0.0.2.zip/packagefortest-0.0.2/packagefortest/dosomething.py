def work():
    print("I'm working!")
def sleep():
    print("I'm sleeping!")


